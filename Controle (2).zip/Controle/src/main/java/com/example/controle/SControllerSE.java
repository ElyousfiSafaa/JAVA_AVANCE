package com.example.controle;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.io.*;
import java.net.Socket;


public class SControllerSE {
    @FXML
    private TextField HostId;
    @FXML
    private TextField myMsgID;
    @FXML
    private TextField PortId;
    @FXML
    private ListView TestView;
    PrintWriter pw;


    @FXML
    protected void onConnect() throws IOException {
        String host=HostId.getText();
        int port=Integer.parseInt(PortId.getText());
        //Socket
        Socket s=new Socket(host,port);
        InputStream IS = s.getInputStream();//Lire un octet
        InputStreamReader ISR = new InputStreamReader(IS); // ire un caractère
        BufferedReader BR = new BufferedReader(ISR); //Lire une chaîne de caractères
        OutputStream OS = s.getOutputStream();//Ecrire un octet
        String Ip = s.getRemoteSocketAddress().toString();
        pw=new PrintWriter(OS,true);
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try {
                        String reponse=BR.readLine();
                        Platform.runLater(()->{
                            TestView.getItems().add(reponse);
                        });

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

        }).start();
    }
    @FXML
    public void onSubmit(){
        String msg=myMsgID.getText();
        pw.println(msg);
    }
}
