package com.example.controle;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ChatWithServer_SE extends Thread{
    private int ClientNbre; // va s'incrémenter lorsque j'accepte un client
    private List<Communication> ClientConnectés = new ArrayList<Communication>();

    public static void main(String[] args) {
        new ChatWithServer_SE().start();
        /*J'ai créé un nouveau objet et lui donner la méthode
       start qui va chercher la méthode run pour exécuter le code dans run()*/

    }

    @Override //On redéfinit la méthode run
    public void run() {
        try {
            ServerSocket SE = new ServerSocket(1234);
            System.out.println("Le serveur essaie de demarrer ....");
            while (true) {
                Socket S = SE.accept(); // Accepter tous les clients
                ++ClientNbre;
                Communication newCommunication = new Communication(S, ClientNbre);//Communication prend en paramètre socket
                ClientConnectés.add(newCommunication);// Ajouter le client connecté à la liste
                newCommunication.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //On crée la classe Communication (classe interne)
    public class Communication extends Thread {
        private int ClientNumber;
        private Socket s;

        Communication(Socket s, int ClientNumber) {
            this.s = s;
            this.ClientNumber = ClientNumber;
        }

        @Override
        public void run() {//Dans le code, on veut lire & écrire
            try {
                InputStream IS = s.getInputStream();// Lire un octet
                InputStreamReader ISR = new InputStreamReader(IS); // lire un caractère
                BufferedReader BR = new BufferedReader(ISR); //Lire une chaîne de caractères
                OutputStream OS = s.getOutputStream();//Ecrire un octet
                String Ip = s.getRemoteSocketAddress().toString();
                System.out.println("Le client numero:" + ClientNumber + "et son IP:" + Ip);
                PrintWriter pw = new PrintWriter(OS, true); //Ecrire chaine par chaine .Chaine de caractere
                pw.println("Vous etes le client" + ClientNumber);
                pw.println("Envoyer le message que vous voulez");
                while (true) {
                    String UserRequest = BR.readLine();//Lire ligne par ligne
                    if (UserRequest.contains("=>")) {// Est ce-que la Chaine de caractères contient le symbole =>
                        String[] userMessage = UserRequest.split("=>");
                        if (userMessage.length == 2) {
                            String msg = userMessage[1];
                            int numeroClient = Integer.parseInt(userMessage[0]);
                            Send(msg, s, numeroClient);
                        }
                    } else {
                        Send(UserRequest, s, -1);
                    }

                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        void Send(String UserRequest, Socket socket, int nbre) throws IOException {
            for (Communication client : ClientConnectés) {

                if (client.s != socket) {
                    if (client.ClientNumber == nbre || nbre == -1) { // -1 => diffuser à tous le monde
                        PrintWriter pw = new PrintWriter(client.s.getOutputStream(), true);
                        pw.println(UserRequest);
                    }
                }
            }
        }
    }

}
