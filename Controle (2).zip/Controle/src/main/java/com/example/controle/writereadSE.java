package com.example.controle;

import java.io.*;
import java.util.HashSet;
import java.util.Set;

public class writereadSE{
    File fichier;
    public writereadSE(File fichier) {
        this.fichier = fichier;
    }
    void writeSE(ManagerSE manager) throws IOException {
        ManagerSE mn;
        ObjectInputStream entree=null;
        ObjectOutputStream sortie=null;
        boolean flag=false;
        File temporaire=new File("temp.txt");
        sortie=new ObjectOutputStream(new FileOutputStream(temporaire));
        try{
            entree = new ObjectInputStream(new FileInputStream(fichier));
            mn = (ManagerSE) entree.readObject();
            while(mn!=null) {
                if (manager.ID.equals(mn.ID)) {
                    sortie.writeObject(manager);
                    flag = true;
                } else {
                    sortie.writeObject(mn);
                }
                mn = (ManagerSE) entree.readObject();
            }

        }catch(FileNotFoundException e) {}
        catch (EOFException e) {
            entree.close();

        }
        catch (ClassNotFoundException e){

        }
        if(!flag) sortie.writeObject(manager);
        sortie.close();
        fichier.delete();
        temporaire.renameTo(fichier);


    }
    Set<ManagerSE> ReadSE() throws IOException{
        ManagerSE mn;
        Set<ManagerSE> manager = new HashSet<ManagerSE>();
        ObjectInputStream entree=new ObjectInputStream((new FileInputStream(fichier)));
        try{
            mn=(ManagerSE) entree.readObject();
            while(mn!=null)
            {
                manager.add(mn);
                mn=(ManagerSE) entree.readObject();            }
        }catch(EOFException e)
        {
            entree.close();
        } catch (ClassNotFoundException e) {

        }
        return  manager;
    }



}
